/**
 * @author <Arunkumar Sriharish Muthumalai - s3938156>
 */
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

// Define the ClaimProcessManager interface
interface ClaimProcessManager {
    void addClaim(Claim claim);
    void updateClaim(String claimId, Claim updatedClaim);
    void deleteClaim(String claimId);
    Claim getClaim(String claimId);
    List<Claim> getAllClaims();
    void saveClaimsToFile(String filename);
}

// Define the Claim class
class Claim {
    private String id;
    private Date claimDate;
    private String insuredPerson;
    private String cardNumber;
    private Date examDate;
    private List<String> documents;
    private double claimAmount;
    private String status;
    private String receiverBankingInfo;

    public Claim(String id, Date claimDate, String insuredPerson, String cardNumber, Date examDate,
                 List<String> documents, double claimAmount, String status, String receiverBankingInfo) {
        // Ensure the provided ID follows the format c-numbers with 7 numbers
        if (!id.matches("c-\\d{7}")) {
            throw new IllegalArgumentException("Invalid claim ID format. Must be in the format c-numbers with 7 numbers.");
        }
        this.id = id;
        this.claimDate = claimDate;
        this.insuredPerson = insuredPerson;
        this.cardNumber = cardNumber;
        this.examDate = examDate;
        this.documents = documents;
        this.claimAmount = claimAmount;
        this.status = status;
        this.receiverBankingInfo = receiverBankingInfo;
    }

    // Getters and setters
    public String getId() {
        return id;
    }

    @Override
    public String toString() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        return "Claim{" +
                "id='" + id + '\'' +
                ", claimDate=" + dateFormat.format(claimDate) +
                ", insuredPerson='" + insuredPerson + '\'' +
                ", cardNumber='" + cardNumber + '\'' +
                ", examDate=" + dateFormat.format(examDate) +
                ", documents=" + documents +
                ", claimAmount=" + claimAmount +
                ", status='" + status + '\'' +
                ", receiverBankingInfo='" + receiverBankingInfo + '\'' +
                '}';
    }
}

// Implement the ClaimProcessManager interface
class InsuranceClaimManager implements ClaimProcessManager {
    private List<Claim> claims;

    public InsuranceClaimManager() {
        this.claims = new ArrayList<>();
        // Add default claims
        addDefaultClaims();
    }

    // Method to add default claims
    private void addDefaultClaims() {
        // Generate valid IDs for default claims
        String id1 = "c-" + generateRandomNumbers(7);
        String id2 = "c-" + generateRandomNumbers(7);

        claims.add(new Claim(id1, new Date(), "Harish", "1234567890",
                new Date(), new ArrayList<>(), 1000.0, "New", "BankX - Harish - 123456"));
        claims.add(new Claim(id2, new Date(), "Arun", "2345678901",
                new Date(), new ArrayList<>(), 1500.0, "Processing", "BankY - Arun - 234567"));
    }

    // Method to generate random numbers of specified length
    private String generateRandomNumbers(int length) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            sb.append((int) (Math.random() * 10));
        }
        return sb.toString();
    }

    @Override
    public void addClaim(Claim claim) {
        claims.add(claim);
        System.out.println("Claim added successfully:");
        System.out.println(claim);
    }

    @Override
    public void updateClaim(String claimId, Claim updatedClaim) {
        for (int i = 0; i < claims.size(); i++) {
            if (claims.get(i).getId().equals(claimId)) {
                claims.set(i, updatedClaim);
                System.out.println("Claim with ID " + claimId + " updated successfully:");
                System.out.println(updatedClaim);
                return;
            }
        }
        System.out.println("Claim with ID " + claimId + " not found.");
    }

    @Override
    public void deleteClaim(String claimId) {
        for (int i = 0; i < claims.size(); i++) {
            if (claims.get(i).getId().equals(claimId)) {
                claims.remove(i);
                System.out.println("Claim with ID " + claimId + " deleted successfully.");
                return;
            }
        }
        System.out.println("Claim with ID " + claimId + " not found.");
    }

    @Override
    public Claim getClaim(String claimId) {
        for (Claim claim : claims) {
            if (claim.getId().equals(claimId)) {
                return claim;
            }
        }
        return null;
    }

    @Override
    public List<Claim> getAllClaims() {
        return claims;
    }

    @Override
    public void saveClaimsToFile(String filename) {
        try (FileWriter writer = new FileWriter(filename)) {
            for (Claim claim : claims) {
                writer.write(claim.toString() + "\n");
            }
            System.out.println("Claims saved to " + filename + " successfully.");
        } catch (IOException e) {
            System.out.println("An error occurred while saving claims to file: " + e.getMessage());
        }
    }
}

public class Main {
    public static void main(String[] args) {
        InsuranceClaimManager claimManager = new InsuranceClaimManager();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Insurance Claim Management System");
        while (true) {
            System.out.println("Choose an option:");
            System.out.println("1. Add a claim");
            System.out.println("2. Update a claim");
            System.out.println("3. Delete a claim");
            System.out.println("4. Get a claim by ID");
            System.out.println("5. Get all claims");
            System.out.println("6. Save claims to file");
            System.out.println("7. Exit");

            int option = scanner.nextInt();
            scanner.nextLine(); // consume newline character

            switch (option) {
                case 1:
                    addClaim(claimManager, scanner);
                    break;
                case 2:
                    updateClaim(claimManager, scanner);
                    break;
                case 3:
                    deleteClaim(claimManager, scanner);
                    break;
                case 4:
                    getClaim(claimManager, scanner);
                    break;
                case 5:
                    getAllClaims(claimManager);
                    break;
                case 6:
                    saveClaimsToFile(claimManager, scanner);
                    break;
                case 7:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid option. Please choose again.");
            }
        }
    }

    private static void addClaim(InsuranceClaimManager claimManager, Scanner scanner) {
        System.out.println("Adding a claim:");
        System.out.print("Enter claim ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter insured person: ");
        String insuredPerson = scanner.nextLine();
        System.out.print("Enter card number: ");
        String cardNumber = scanner.nextLine();
        System.out.print("Enter exam date (yyyy-MM-dd): ");
        Date examDate = parseDate(scanner.nextLine());
        System.out.print("Enter claim amount: ");
        double claimAmount = scanner.nextDouble();
        scanner.nextLine(); // consume newline character
        System.out.print("Enter status: ");
        String status = scanner.nextLine();
        System.out.print("Enter receiver banking info: ");
        String receiverBankingInfo = scanner.nextLine();
        Claim claim = new Claim(id, new Date(), insuredPerson, cardNumber, examDate,
                new ArrayList<>(), claimAmount, status, receiverBankingInfo);
        claimManager.addClaim(claim);
    }

    private static void updateClaim(InsuranceClaimManager claimManager, Scanner scanner) {
        System.out.println("Updating a claim:");
        System.out.print("Enter claim ID to update: ");
        String updateClaimId = scanner.nextLine();
        Claim existingClaim = claimManager.getClaim(updateClaimId);
        if (existingClaim != null) {
            System.out.println("Enter updated details:");
            System.out.print("Enter insured person: ");
            String insuredPerson = scanner.nextLine();
            System.out.print("Enter card number: ");
            String cardNumber = scanner.nextLine();
            System.out.print("Enter exam date (yyyy-MM-dd): ");
            Date examDate = parseDate(scanner.nextLine());
            System.out.print("Enter claim amount: ");
            double claimAmount = scanner.nextDouble();
            scanner.nextLine(); // consume newline character
            System.out.print("Enter status: ");
            String status = scanner.nextLine();
            System.out.print("Enter receiver banking info: ");
            String receiverBankingInfo = scanner.nextLine();
            Claim updatedClaim = new Claim(updateClaimId, new Date(), insuredPerson, cardNumber, examDate,
                    new ArrayList<>(), claimAmount, status, receiverBankingInfo);
            claimManager.updateClaim(updateClaimId, updatedClaim);
        } else {
            System.out.println("Claim with ID " + updateClaimId + " not found.");
        }
    }

    private static void deleteClaim(InsuranceClaimManager claimManager, Scanner scanner) {
        System.out.println("Deleting a claim:");
        System.out.print("Enter claim ID to delete: ");
        String deleteClaimId = scanner.nextLine();
        claimManager.deleteClaim(deleteClaimId);
    }

    private static void getClaim(InsuranceClaimManager claimManager, Scanner scanner) {
        System.out.println("Getting a claim:");
        System.out.print("Enter claim ID: ");
        String claimId = scanner.nextLine();
        Claim claim = claimManager.getClaim(claimId);
        if (claim != null) {
            System.out.println("Found claim:");
            System.out.println(claim);
        } else {
            System.out.println("Claim with ID " + claimId + " not found.");
        }
    }

    private static void getAllClaims(InsuranceClaimManager claimManager) {
        System.out.println("Getting all claims:");
        List<Claim> allClaims = claimManager.getAllClaims();
        for (Claim c : allClaims) {
            System.out.println(c);
        }
    }

    private static void saveClaimsToFile(InsuranceClaimManager claimManager, Scanner scanner) {
        System.out.println("Saving claims to file...");
        System.out.print("Enter filename: ");
        String filename = scanner.nextLine();
        claimManager.saveClaimsToFile(filename);
    }

    private static Date parseDate(String dateString) {
        try {
            return new SimpleDateFormat("yyyy-MM-dd").parse(dateString);
        } catch (ParseException e) {
            System.out.println("Invalid date format. Please enter in yyyy-MM-dd format.");
            return null;
        }
    }
}
